// =====================================================================
// Customer Ticketing Portal Logic - Student 3 (Co-Member)
// =====================================================================

let activeCategoryId = '';
let searchDebounceTimer = null;
let currentEventForBooking = null;

document.addEventListener('DOMContentLoaded', async () => {
    await ensureCustomerAuthenticated();
    await loadCategories();
    loadCatalogEvents();
    updateBookingsCount();
});

async function ensureCustomerAuthenticated() {
    let token = ApiClient.getToken();
    let user = ApiClient.getUser();

    if (token && user) {
        document.getElementById('customer-name').textContent = user.full_name;
        const initials = user.full_name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
        document.getElementById('customer-avatar').textContent = initials;
    } else {
        const nameEl = document.getElementById('customer-name');
        if (nameEl) nameEl.textContent = 'Guest User';
        const avatarEl = document.getElementById('customer-avatar');
        if (avatarEl) avatarEl.textContent = '👤';
        const navUser = document.querySelector('.nav-user');
        if (navUser) {
            const btn = navUser.querySelector('button');
            if (btn) {
                btn.textContent = 'Sign In';
                btn.className = 'btn btn-primary btn-sm';
                btn.onclick = () => window.location.href = 'login.html';
            }
        }
    }
}

// ---------------------------------------------------------------------
// 1. CATEGORIES & SEARCH
// ---------------------------------------------------------------------
async function loadCategories() {
    try {
        const res = await ApiClient.get('categories');
        const categories = Array.isArray(res.data) ? res.data : [];
        const container = document.getElementById('category-pills');
        const pills = categories.map(c => `
            <button class="pill" data-cat="${c.id}" onclick="selectCategory(this, '${c.id}')">${c.category_name}</button>
        `).join('');
        container.innerHTML = `<button class="pill active" data-cat="" onclick="selectCategory(this, '')">All Categories</button>` + pills;
    } catch (err) {
        console.error("Error loading categories:", err);
    }
}

function selectCategory(btn, catId) {
    document.querySelectorAll('.category-pills .pill').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    activeCategoryId = catId;
    loadCatalogEvents();
}

function debounceSearch() {
    clearTimeout(searchDebounceTimer);
    searchDebounceTimer = setTimeout(() => {
        loadCatalogEvents();
    }, 300);
}

// ---------------------------------------------------------------------
// 2. EVENTS CATALOG
// ---------------------------------------------------------------------
async function loadCatalogEvents() {
    const grid = document.getElementById('catalog-grid');
    grid.innerHTML = `<div class="loading-state">Loading event listings from REST API...</div>`;

    const search = document.getElementById('catalog-search').value.trim();
    const sortVal = document.getElementById('catalog-sort').value;
    const [sortCol, sortOrder] = sortVal.split(':');

    const params = {
        status: 'published',
        limit: 50,
        sort: sortCol,
        order: sortOrder
    };

    if (search) params.search = search;
    if (activeCategoryId) params.category_id = activeCategoryId;

    try {
        const res = await ApiClient.get('events', params);
        const events = Array.isArray(res.data) ? res.data : [];
        document.getElementById('results-count').textContent = `Showing ${events.length} event(s)`;

        if (events.length === 0) {
            grid.innerHTML = `<div class="loading-state">No events found matching your query.</div>`;
            return;
        }

        grid.innerHTML = events.map(e => `
            <div class="event-card">
                <img class="event-banner" src="${e.banner_image || 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800'}" alt="${e.title}">
                <div class="event-body">
                    <span class="event-category-tag" style="color:${e.badge_color}">${e.category_name}</span>
                    <h3 class="event-title">${e.title}</h3>
                    <div class="event-meta">
                        📍 ${e.venue_name}, ${e.venue_city}<br>
                        📅 ${new Date(e.start_time).toLocaleDateString('en-MY', { weekday:'short', day:'numeric', month:'short', year:'numeric'})}
                    </div>
                    <p class="event-desc">${e.description.substring(0, 100)}...</p>
                    
                    <div class="event-footer">
                        <div>
                            <div class="ticket-price">RM ${Number(e.ticket_price).toFixed(2)}</div>
                            <span class="ticket-seats">${e.available_tickets} seats remaining</span>
                        </div>
                        <button class="btn btn-primary btn-sm" onclick='openBookingModal(${JSON.stringify(e)})' ${e.available_tickets <= 0 ? 'disabled' : ''}>
                            ${e.available_tickets > 0 ? 'Reserve Seat' : 'Sold Out'}
                        </button>
                    </div>
                </div>
            </div>
        `).join('');

    } catch (err) {
        grid.innerHTML = `<div class="loading-state text-danger">Error: ${err.message}</div>`;
    }
}

// ---------------------------------------------------------------------
// 3. BOOKING RESERVATION & CHECKOUT
// ---------------------------------------------------------------------
function openBookingModal(e) {
    if (!ApiClient.getToken()) {
        if (confirm("Please sign in with your Customer account to reserve event tickets.\n\nClick OK to open the Sign In page.")) {
            window.location.href = 'login.html';
        }
        return;
    }

    currentEventForBooking = e;
    document.getElementById('book-event-id').value = e.id;
    document.getElementById('book-event-title').textContent = e.title;
    document.getElementById('book-event-venue').textContent = `${e.venue_name} • ${e.venue_city}`;
    document.getElementById('book-event-unit-price').textContent = `RM ${Number(e.ticket_price).toFixed(2)}`;
    
    document.getElementById('book-qty').value = 1;
    document.getElementById('book-qty').max = Math.min(10, e.available_tickets);
    
    updateSummary();
    document.getElementById('booking-modal').classList.remove('hidden');
}

function closeBookingModal() {
    document.getElementById('booking-modal').classList.add('hidden');
    currentEventForBooking = null;
}

function changeQty(delta) {
    const qtyInput = document.getElementById('book-qty');
    let val = parseInt(qtyInput.value) + delta;
    const max = parseInt(qtyInput.max) || 10;
    if (val < 1) val = 1;
    if (val > max) val = max;
    qtyInput.value = val;
    updateSummary();
}

function updateSummary() {
    if (!currentEventForBooking) return;
    const qty = parseInt(document.getElementById('book-qty').value);
    const unit = parseFloat(currentEventForBooking.ticket_price);
    const total = qty * unit;

    document.getElementById('summary-qty').textContent = `${qty} pass(es)`;
    document.getElementById('summary-unit').textContent = `RM ${unit.toFixed(2)}`;
    document.getElementById('summary-total').textContent = `RM ${total.toFixed(2)}`;
}

async function handleBookingSubmit(e) {
    e.preventDefault();
    const btn = document.getElementById('btn-confirm-checkout');
    btn.disabled = true;
    btn.textContent = 'Contacting External QR API...';

    const payload = {
        event_id: parseInt(document.getElementById('book-event-id').value),
        ticket_quantity: parseInt(document.getElementById('book-qty').value),
        payment_method: document.getElementById('book-payment-method').value
    };

    try {
        const res = await ApiClient.post('bookings', payload);
        showToast('Ticket reservation confirmed! QR pass ready.', 'success');
        closeBookingModal();
        
        // Show ticket pass modal immediately
        viewTicketPass(res.data.qr_code_url, res.data.booking_reference, res.data.event_title, `${res.data.ticket_quantity} pass(es)`);
        
        loadCatalogEvents();
        updateBookingsCount();
    } catch (err) {
        showToast(err.message, 'error');
    } finally {
        btn.disabled = false;
        btn.textContent = 'Confirm & Generate QR Pass';
    }
}

// ---------------------------------------------------------------------
// 4. MY BOOKINGS & DIGITAL PASSES
// ---------------------------------------------------------------------
async function updateBookingsCount() {
    try {
        const res = await ApiClient.get('bookings');
        const count = Array.isArray(res.data) ? res.data.length : 0;
        document.getElementById('my-bookings-count').textContent = count;
    } catch (err) {
        // quiet
    }
}

async function loadMyBookings() {
    const grid = document.getElementById('my-bookings-grid');
    grid.innerHTML = `<div class="loading-state">Loading your ticket passes...</div>`;

    try {
        const res = await ApiClient.get('bookings');
        const bookings = Array.isArray(res.data) ? res.data : [];
        document.getElementById('my-bookings-count').textContent = bookings.length;

        if (bookings.length === 0) {
            grid.innerHTML = `<div class="loading-state">You do not have any active bookings yet. Browse events to make a reservation!</div>`;
            return;
        }

        grid.innerHTML = bookings.map(b => `
            <div class="booking-card">
                <div class="booking-card-header">
                    <div>
                        <span class="booking-ref-badge">${b.booking_reference}</span>
                        <h4 style="margin-top:6px;font-size:16px;">${b.event_title}</h4>
                        <small class="text-muted">📍 ${b.venue_name} (${b.venue_city})</small>
                    </div>
                    <span class="booking-status-${b.booking_status}">${b.booking_status}</span>
                </div>

                <div style="font-size:13px;line-height:1.8;color:#475569;">
                    🎟️ <strong>Reserved Passes:</strong> ${b.ticket_quantity} tickets<br>
                    💳 <strong>Amount Paid:</strong> RM ${Number(b.total_amount).toFixed(2)} (${b.payment_method})<br>
                    🕒 <strong>Booking Date:</strong> ${new Date(b.created_at).toLocaleDateString()}
                </div>

                <div class="booking-actions">
                    <button class="btn btn-primary btn-sm" onclick="viewTicketPass('${b.qr_code_url}', '${b.booking_reference}', '${b.event_title.replace(/'/g, "\\'")}', '${b.ticket_quantity} tickets')">
                        📲 View Entry QR Pass
                    </button>
                    ${b.booking_status === 'confirmed' ? `
                        <button class="btn btn-outline-danger btn-sm" onclick="cancelBooking(${b.id}, '${b.booking_reference}')">
                            Cancel Booking
                        </button>
                    ` : ''}
                </div>
            </div>
        `).join('');

    } catch (err) {
        grid.innerHTML = `<div class="loading-state text-danger">Error: ${err.message}</div>`;
    }
}

function viewTicketPass(qrUrl, ref, title, qty) {
    document.getElementById('ticket-qr-img').src = qrUrl;
    document.getElementById('ticket-ref').textContent = ref;
    document.getElementById('ticket-title').textContent = title;
    document.getElementById('ticket-qty').textContent = qty;
    document.getElementById('ticket-modal').classList.remove('hidden');
}

function closeTicketModal() {
    document.getElementById('ticket-modal').classList.add('hidden');
}

async function cancelBooking(id, ref) {
    if (!confirm(`Are you sure you want to cancel booking '${ref}'? Your tickets will be released back to the event pool.`)) return;

    try {
        await ApiClient.delete(`bookings/${id}`);
        showToast(`Booking ${ref} cancelled successfully`, 'success');
        loadMyBookings();
        updateBookingsCount();
    } catch (err) {
        showToast(err.message, 'error');
    }
}

// ---------------------------------------------------------------------
// 5. VIEW TOGGLES
// ---------------------------------------------------------------------
function showCatalogView() {
    document.getElementById('catalog-view').classList.remove('hidden');
    document.getElementById('bookings-view').classList.add('hidden');
    document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
    document.querySelector('.nav-link[href="#events"]').classList.add('active');
}

function showBookingsView() {
    document.getElementById('catalog-view').classList.add('hidden');
    document.getElementById('bookings-view').classList.remove('hidden');
    document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
    document.querySelector('.nav-link[href="#my-bookings"]').classList.add('active');
    loadMyBookings();
}

function logoutCustomer() {
    ApiClient.logout('login.html');
}

